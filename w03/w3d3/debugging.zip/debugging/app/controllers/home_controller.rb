class HomeController < ApplicationController
  respond_to :html

  def home
  	1/0
  end

end