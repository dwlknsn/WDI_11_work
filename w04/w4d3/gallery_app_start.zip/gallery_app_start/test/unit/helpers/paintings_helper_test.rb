require 'test_helper'

class PaintingsHelperTest < ActionView::TestCase
end
