# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
GalleryApp::Application.config.secret_token = '3492abdb0c19d4350127b4314548de0092e5e88775eb66c8a2e47d9c18306790a4a0b9754dfabad66c04d877aa7a7e00f69bda44dad58ba1eead0324a1e3a43d'
